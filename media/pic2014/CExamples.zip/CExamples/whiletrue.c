#include <stdio.h>
void main()
{
  int i = 0;
  int j = 5;
  do {
    i++;
    printf("%d\n", i);
  } while(j =! j);
}