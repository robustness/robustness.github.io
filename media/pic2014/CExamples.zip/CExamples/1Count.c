#include <stdio.h>

int bitcount (unsigned long value) {
    int count = 0;
    while (value > 0) {
        if ((value & 1) == 1)
            count++;
        value >>= 1;
    }
    return count;
}

int bitcount1 (unsigned long x)
{
    int n = 0;
    if (x) do ++n;
        while (x &= x-1);
    return n;
}

/* assume unsigned long is 32 bits */
int bitcount2 (unsigned long x)
{
    x -= ((x>>1)&013333333333)+((x>>2)&01111111111);
    x = ((x>>3)+x)&030707070707;
    x += x>>18;
    return ((x>>12)+(x>>6)+x)&63;
}

int bitcount3(unsigned long i)
{
    i = i - ((i >> 1) & 0x55555555);
    i = (i & 0x33333333) + ((i >> 2) & 0x33333333);
    return (((i + (i >> 4)) & 0x0F0F0F0F) * 0x01010101) >> 24;
}
int main()
{
    int i = 121;
    printf("Method 0: %d\n", bitcount(i));
    printf("Method 1: %d\n", bitcount1(i));
    printf("Method 2: %d\n", bitcount2(i));
    printf("Method 3: %d\n", bitcount3(i));
}