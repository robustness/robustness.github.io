/* this is a C-style comment 
 * You generally want to palce
 * all file includes at start of file
 * */
#include <stdio.h>
#include <stdlib.h>

int
main (int argc, char **argv)
{
  // this is a C++-style comment
  // printf prototype in stdio.h
	printf("Hello, Program name is = %s\n",
            argv[0]);
	exit(0);
}
