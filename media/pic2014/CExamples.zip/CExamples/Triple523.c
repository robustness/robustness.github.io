#include <stdio.h>
#include <math.h>

int main()
{
  printf("%d\n", (int)5/5 + sqrt(5));
}