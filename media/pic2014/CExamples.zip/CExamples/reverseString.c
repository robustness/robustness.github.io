#include <ctype.h>
#include <stdio.h>
#include <string.h>
char * reverse(char s[])
{
	int c, i, j;

	for (i = 0, j = strlen(s)-1; i < j; i++, j-- )
	{
	    c = s[i];
	    s[i] = s[j];
	    s[j] = c;
	}
  return s;
}

int main()
{
	char String[] = "Life is good!";
	printf("%s\n", reverse(String));
	return 0;
}



