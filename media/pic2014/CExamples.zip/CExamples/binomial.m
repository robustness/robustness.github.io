function binomial(m, n, p)

res = 0;
for k = n+1:m
    res = res + nchoosek(m,k) * (p^k) * (1-p)^(m-k);
end
res
