#include <stdio.h>
main()
{
  printf("%d\n", sizeof(void *));

  for (;;);

}