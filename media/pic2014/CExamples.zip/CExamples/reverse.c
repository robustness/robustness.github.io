#include <stdio.h>
#include <stdlib.h>
void ReverseString (char str[], int start, int end) { 

char temp;
while (end > start) {
/* Exchange characters */ temp = str [start];
str [start] = str [end] ; str[end] = temp;
/* Move indices towards middle */
           start++; end--;
}
return;
}

int main()
{
	/* what happen if not 14?*/
	char str[14] = "life is good!";
	printf("%s\n", str);
	ReverseString(str,0,12);
	printf("%s\n", str);
}