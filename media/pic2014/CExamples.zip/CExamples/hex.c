#include <stdio.h>
int main()
{
  int a = 300;
  printf("%x\n", a);
}