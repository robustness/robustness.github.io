import numpy as np
import scipy as sp
import matplotlib.pyplot as plt

a = np.array([0,1,2,3,4,5])
a.ndim
a.shape

b = a.reshape((3,2))
b.ndim
b.shape

b[1][0] = 77
b
a

c = a.reshape((3,2)).copy()
c
c[0][0] = -99
a
c

a*2
a**2
# ordinary python lists
[1,2,3,4,5]*2
[1,2,3,4,5]**2

a[np.array([2,3,4])]

a > 4
a[a>4]
a.clip(0,4)

x = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
y = np.array([-1, 0.2, 0.9, 2.1, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0])
# y = [x 1][m c]' = x*m + c
A = np.vstack([x, np.ones(len(x))]).T
m, c = np.linalg.lstsq(A, y)[0]


T = [(1, 2), (3, 4), (5, 6)]
for (a, b) in T:
  print(a,b)

list(range(−5, 5))
list(range(5, −5, −1))

range(0) # it is []

n=4
for j in range(n):
  for i in range(j+1):
    print i,j

# for j = 0:n-1
#   for i = 0:j
#       print i,j

x = np.array([ 0,   1,   2,   3,   4,   5,   6,   7,   8])
y = np.array([-1, 0.2, 0.9, 2.1, 3.0, 4.0, 5.0, 6.0, 7.0])
n=4
for j in range(n):
  for i in range(j+1):
    print x[i:j+1]
    print y[i:j+1]

#######################################
import numpy as np
x = np.array([ 0,   1,   2,   3,   4,   5,   6,   7,   8])
y = np.array([-1, 0.2, 0.9, 2.1, 3.0, 4.0, 5.0, 6.0, 7.0])
gerr = np.array([])
n=4
for j in range(n):
  for i in range(j+1):
    subx = x[i:j+1]
    suby = y[i:j+1]
    A = np.vstack([subx, np.ones(len(subx))]).T
    err = np.linalg.lstsq(A, suby)[1]
    if err.size == 0:
      gerr = np.append(gerr,0)
    gerr = np.append(gerr,err[0])

#######################################
import numpy as np
x = np.array([ 0,   1,   2,   3,   4,   5,   6,   7,   8])
y = np.array([-1, 0.2, 0.9, 2.1, 3.0, 4.0, 5.0, 6.0, 7.0])
gerr = np.array([])
n=4
for j in range(n):
  for i in range(j+1):
    subx = x[i:j+1]
    suby = y[i:j+1]
    A = np.vstack([subx, np.ones(len(subx))]).T
    err = np.linalg.lstsq(A, suby)[1]
    if err.size == 0:
      gerr = np.append(gerr,0)
    else: gerr = np.append(gerr,err[0])

#######################################
# How to add element to ditionary
n = 4
D = {}
for j in range(n):
  for i in range(j+1):
    D[(i,j)] = 1
#######################################
# array possibly is 0, error is 0
import numpy as np
x = np.array([0])
y = np.array([-1])
A = np.vstack([x, np.ones(len(x))]).T
m, c = np.linalg.lstsq(A, y)[0]
err = np.linalg.lstsq(A, y)[1]
err.size

#######################################
# node index 0:8
import numpy as np
x = np.array([ 0,   1,   2,   3])
y = np.array([-1, 0.2, 0.9, 2.1])
D = {}
n = 4; C = 1
for j in range(n):
  for i in range(j+1):
    subx = x[i:j+1]
    suby = y[i:j+1]
    A = np.vstack([subx, np.ones(len(subx))]).T
    err = np.linalg.lstsq(A, suby)[1]
    if err.size == 0: D[(i,j)] = 0
    else: D[(i,j)] = err[0]
# D[(3,3)] how to search dictionary

def segmented_least_square(j):
  print 'Calling', j
  if j <= 0:
    return 0
  elif j <= 2:
    return C
  else:
    options = np.array([])
    for i in range(j+1):
      print i,j
      np.append(options,D[(i,j)] + C + segmented_least_square(i-1))
      print options
    return min(options)

segmented_least_square(3)







