def fac(n):
  print 'Now we are calling fac ',n
  if n <= 1:
    return 1
  else:
    return n*fac(n-1)
