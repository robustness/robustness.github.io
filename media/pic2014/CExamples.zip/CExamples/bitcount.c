#include <stdio.h>
int bitcount(unsigned x)
{
	int b;
	for (b = 0; x!= 0; x >>= 1)
	    b++;
	return b;
}

int main()
{
	unsigned a = 200;
	printf("%d\n", bitcount(a));
	return 0;
}