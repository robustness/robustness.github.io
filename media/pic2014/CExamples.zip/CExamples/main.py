#!/usr/bin/python -tt
import sys

# Define a main() function
def main():
  print sys.argv
if __name__ == '__main__':
  main()
