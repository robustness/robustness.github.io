/*
 * Declaration: void *bsearch(const void *key, 
 const void *buf, size_t num, 
 size_t size, int (*compare)(const void *, const void *));
 */

/*
 * Return: returns a pointer to the first member 
 * that matches *key.
 * A null pointer is returned if not found.
 */

/* 
 * Parameter:   The array must be sorted in ascending order.
 * The number of elements in the array is num.
 * The size (in bytes) of each element is described by size.
 */

#include <stdlib.h>
#include <ctype.h>
#include <stdio.h>

char *alpha = "abcdefghijklmnopqrstuvwxyz";

int comp(const void *ch, const void *s);

int main(void)
{
    char ch;
    char *p;

    printf("Enter a character: ");
    ch = getchar();
    ch = tolower(ch);
    
    p = (char *) bsearch(&ch, alpha, 26, 1, comp);

    if(p) 
        printf(" %c is in alphabet\n", *p);
    else 
        printf("is not in alphabet\n");

    return 0;
}

/* Compare two characters. */
int comp(const void *ch, const void *s)
{
    return *(char *)ch - *(char *)s;
}
