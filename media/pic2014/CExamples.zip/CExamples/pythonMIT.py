a = 2**1000
b = 2**999
a/b

s = 0.0
for i in range(10): s += 0.1
s
print s

// cautious about == for float
import math
a = math.sqrt(2)
a
a*a == 2
a*a

a = 6
a = 'Hello'
len(a)
len('Hello')
A
'Hello' + 6
'Hello' +str(6)