#include <stdio.h>
int EulerCircuit(int mat[4][4], int n);

int main()
{
	int mat[4][4] = {{0,1,2,2}, {1,0,1,1}, {2,1,0,0}, {2,1,0,0}};
	int num;

	num = EulerCircuit(mat,4);
	if(num > 2)
		printf("No Eurler Circuit\n");
	else if (num == 2 || num == 0)
		printf("Eurler Circuit Existing!!!\n");
	return 0;
}

int EulerCircuit(int mat[4][4], int n)
{
	int i, j, count = 0, degree;

	for (i = 0; i < n; i++)
	{
		degree = 0;
		for (j = 0; j < n; j++)
		{
			degree += mat[i][j];
		}
		if (degree % 2 != 0)
			count++;
	}

	return count;
}

