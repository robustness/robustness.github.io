#include <stdio.h>
int main()
{
  int nc;
  nc = 0;
  printf("End with Ctr+D\n");
  while (getchar() != EOF)
    ++nc;
  printf("character counter: %d\n", nc);
}
