#include <stdio.h>
int main()
{
	int i, n = 23;
	int a[100];
	for (i = 0; i < n; i++)
		a[i] = i;
	for (i = 0; i < n; i++)
	    printf("%6d%c", a[i], (i%10==9 || i==n-1) ? '\n':' ');
    
	//printf("You have %d item%s. \n", n, n==1?"":"s");
}