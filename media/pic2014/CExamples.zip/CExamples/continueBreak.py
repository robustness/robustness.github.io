while True:
  print('Who are you?')
  name = input()
  if name != 'Lei':
    continue
  print('Hello, Lei, What is your passwd?')
  password = input()
  if password == 'swordfish':
    break
print('Access granted')