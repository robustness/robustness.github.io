import string

# 1
s ='Time is a train, making the future the past'
print s
print string.capwords(s)

# 2
leet = string.maketrans('abegiloprstz','463611092572')
s ='Time is a train, making the future the past'
print s
print s.translate(leet)

# 3
import string
values = {'var':'foo'}

t = string.Template("""
  Variable         :$var
  Escape           :$$
  Variable in text :${var}iable
  """)

print 'TEMPLATE:', t.substitute(values)

# 4
import string
values = {'var':'foo'}
s = """
Variable :%(var)s
Escape   :%%
Variable in text : %(var)siable
"""
print 'INTERPOLATION:', s % values

# 5
import Queue
q = Queue.Queue()
for i in range(5):
  q.put(i)

while not q.empty():
  print q.get(),

# what's the difference between
# "print q.get()," and "print q.get()"

# 6
import Queue
#Lifo: Last in first out

q = Queue.LifoQueue()
for i in range(5):
  q.put(i)

while not q.empty():
  print q.get(),





