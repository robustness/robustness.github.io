def cutRod(p,n):
  print 'p and n is', p,n
  if n == 0:
    return 0
  q = float("-inf")
  for i in range(n):
    q = max(q,p[i] + cutRod(p,n-i-1))
  print 'q is ',q
  return q

p =[1, 5, 8, 9, 10, 17, 17, 20, 24, 30]
cutRod(p,10)
