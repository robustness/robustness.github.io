#include <stdio.h>
int main()
{
  int i;
  float x = 0.0;
  float y = 1.00000;
  printf("the size of a float %lu\n", sizeof(float));
  for (i = 0; i < 10; i++) {
    printf("Now i is %d\n", i);
    x = x + 0.1;

    if (x == y)
        printf("%f = 1.0\n", x);
    else
        printf("%f is not 1.0\n", x);
  }
  return 0;
}

/*
  float f = 1.0;

  float *pf = &f;
  printf("%x\n", *(int *)pf);
*/
