#include <stdio.h>

main()
{
  int b = (2 + 2 == 4) && !(2 + 2 == 5) && (2 * 2 == 2 + 2);
  printf("%d\n", b);
}