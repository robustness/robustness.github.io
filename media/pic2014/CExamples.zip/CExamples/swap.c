#include <stdio.h>
void swap(int *x, int *y);

main()
{
  int a = 5;
  int b = 6;
  swap(&a,&b);
  printf("a, b : %d %d\n", a,b);
}

void swap(int *x, int *y)
{
  int temp;

  temp = *x;
  *x = *y;
  *y = temp;
}