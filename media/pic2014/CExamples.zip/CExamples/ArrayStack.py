class ArrayStack:
  def __init__ (self):
    self._data = []
  def __len__ (self):
    return len(self._data)
  def is_empty(self):
    return len(self._data) == 0
  def push(self, e):
    self._data.append(e) # new item stored at end of list
  def top(self):
    if self.is_empty():
      raise Empty('Stack is empty')
    return self._data[-1]
  def pop(self):
    if self.is_empty():
      raise Empty('Stack is empty')
    return self._data.pop( ) # remove last item from list


S = ArrayStack()
S.push(5)
S.push(3)
print(len(S))
print(S.pop())
print(S.is_empty())
print(S.pop( ))
print(S.is_empty())
S.push(7)
S.push(9)
print(S.top())
S.push(4)
print(len(S))
print(S.pop())