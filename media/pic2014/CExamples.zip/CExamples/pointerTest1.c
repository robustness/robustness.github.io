#include <stdio.h>
main()
{

  int i = 5;
  int *p = &i;
  int j = 6;

  printf("%p\n", p);
  printf("%p\n", &i);
  printf("%d\n", *p);

  p = &j;
  printf("%p\n", p);
  printf("%p\n", &j);
  printf("%d\n", *p);


}