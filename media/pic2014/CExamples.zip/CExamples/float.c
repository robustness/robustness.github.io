#include <stdio.h>
main()
{
    float f = 0.1;

    float *pf = &f;
    printf("%x\n", *(int *)pf);
    //printf("%lx\n", *(long *)pf);

}