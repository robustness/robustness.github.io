#include <stdio.h>
int main()
{
  int matrix[3][10];

  // pointer -> array with 10 elements
  printf("%p\n", matrix);

  // pointer -> array with 10 elements
  printf("%p\n", matrix+1);

  // array with 10 elements
  printf("%p\n", *(matrix+1));

  // pointer -> array with 10 elements
  printf("%p\n", matrix[1]);

  // starting from the beginning of array, +5
  printf("%p\n", *(matrix+1) + 5);

  //take out value
  printf("%d\n", *(*(matrix+1) + 5));

/*
  //from P226 (from textbook)
  int a[3][4];
  // a[0] is pointer -> array with 4 elements
  // all elements are int type
  // why can not int *b = a
  // since the elements of a is array[4]
  int *b = a[0];

  //take a break; difference of
  // (*p)[10] and *p[10]
  int (*p)[10];
  int m[10] = {0,1,2,3,4,5,6,7,8,9};
  p = &m;
  printf("m address is %p\n", m);
  printf("point address is %p\n", p);

*/
  return 0;

}