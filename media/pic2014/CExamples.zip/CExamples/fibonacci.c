#include <stdio.h>

int Fibonacci(int);

int main()
{
   printf("rabbit is %d\n", Fibonacci(15));
}

int Fibonacci(int n)
{
    printf("calling Fib(%d)\n", n);
    if ((n == 1) || (n == 2))
        return 1;
    else
        return ( Fibonacci(n-1) + Fibonacci(n-2) );
}