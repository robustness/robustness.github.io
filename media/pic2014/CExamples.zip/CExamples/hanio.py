def move(A,B):
  print A,'->',B

def hanio(n, A, B, C):
  if n == 1:
    move(A,C)
  else:
    hanio(n-1, A, C, B)
    move(A,C)
    hanio(n-1, B, A, C)

hanio(3, 'A', 'B', 'C')