import numpy as np
import matplotlib.pyplot as plt

x = np.array([1, 2, 3, 4])
y = np.array([1, 2, 3, 5])
D = {}
points = np.array([])
C = 1

def segmented_least_square(j):
  print 'Calling ', j
  global points, lines, C, D
  if j == -1:
    return 0
  else:
    options = np.array([])
    line = np.array([])
    for i in range(j+1):
      options = np.append(options,D[(i,j)] + C + segmented_least_square(i-1))
    index  = np.where(options == min(options))
    points = np.append(points, index[0][0])
    return min(options)

def calc_error(n):
  global subx, suby
  for j in range(n):
    for i in range(j+1):
      subx = x[i:j+1]
      suby = y[i:j+1]
      A = np.vstack([subx, np.ones(len(subx))]).T
      err = np.linalg.lstsq(A, suby)[1]
      if err.size == 0: D[(i,j)] = 0
      else: D[(i,j)] = err[0]

calc_error(len(x))
mincost = segmented_least_square(len(x)-1)
print 'minimum cost is ', mincost

points = np.unique(points)
points = np.append(points, len(x))
j = 0
while j < len(points)-1:
  if (points[j] == points[j+1] - 1):
    subx = x[points[j]:points[j+1] + 1]
    suby = y[points[j]:points[j+1] + 1]
    j = j + 1
  else :
    subx = x[points[j]:points[j+1]]
    suby = y[points[j]:points[j+1]]
  A = np.vstack([subx, np.ones(len(subx))]).T
  m,c = np.linalg.lstsq(A, suby)[0]
  plt.plot(subx, suby, 'o',markersize=10)
  plt.plot(subx, m*subx + c, 'r')
  j = j + 1
plt.show()

# Appendix
# x = np.array([1, 2, 3, 4,  5,  6, 7, 8])
# y = np.array([1, 2, 3, 51, 4, 20, 12, 87])



