#include <stdio.h>

int i;
void b() { printf("%d ", i++);; }
void c() { b(),b(),b(),b(),b(); }
void a() { c(),c(),c(),c(),c(); }
int main()
{
    i=1;
    a(),a(),a(),a();
    printf("\n");
}