#include <stdio.h>
int main()
{
  int a[] = {0,1,2,3,4,5,6};
  int *p, x;
  p = a;
  printf("%d\n", *p);
  printf("%d\n", *(p+7));
  printf("%d\n", *p+7);
  *(p+7) = 1000;
  printf("%d\n", *(p+7));
  printf("%d\n", *(++p));
  printf("%d\n", *++p);
  printf("%d\n", *(p--));
  p += 3;
  x = *p;
  printf("%d %d\n", x, *(a+3));
  return 0;

}