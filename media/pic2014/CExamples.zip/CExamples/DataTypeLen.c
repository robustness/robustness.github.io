#include <stdio.h>
#include <stdlib.h>
int main()
{
	printf("%lu\n", sizeof(unsigned long int));
}
