#include <stdio.h>
int main()
{

  char ch = 128;
  short s = ch;

  printf("s is %x \n", s);

  s = 129;
  ch = s;


  printf("ch is %d \n", ch);

  //printf("ch is %x \n", ch);
}
/*
  printf("%x\n", b);

  printf("Testing short and char\n");
  printf("%d\n", ch);
  printf("ch %x s %x \n", ch, s);
*/
/*
 * -128~127:  1 + 111 1111: 1000000
 */
