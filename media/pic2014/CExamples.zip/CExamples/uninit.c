#include <stdio.h>
int main()
{
  int a[100][100]={9};
  int i,j;
  for (i = 0; i < 100; i++)
    for (j = 0; j < 100; j++)
      printf("%d ", a[i][j]);
}