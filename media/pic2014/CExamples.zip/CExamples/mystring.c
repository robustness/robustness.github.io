#include <stdio.h>
int main()
{
  int a[10] = {10,11,12,13,14,15,16,17,18,19};
  int i=0;

  for (; i<= 10; i++) {
    a[i] = i*i;
    printf("%d\n", a[i]);
  }
  return 0;
}
